#include <string>
//typedef std::string ItemType;
typedef int ItemType;

struct NodeType 
{
 ItemType info;
 NodeType * link;
};


class  SortedLinkList
{						
public: 		

    bool IsEmpty () const; 

    void Insert (/* in */  ItemType  item); 	

    void Delete (/* in */  ItemType  item);
    void Print () const;

	void ResetList();

	ItemType* getNextItem();
	
	bool hasNext() const;
	 
    // Constructor
    SortedLinkList ();   
    // Copy-constructor
    SortedLinkList (const SortedLinkList&  otherList); 
    // = operator
    SortedLinkList & operator = (const SortedLinkList & otherList);
    // Destructor
    ~SortedLinkList ();  

private:
    void Free();
	 
private:		
    NodeType*  head;
	NodeType* nodePtr;

};	
