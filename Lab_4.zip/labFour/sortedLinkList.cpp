#include <iostream>
using namespace std;

#include "SortedLinkList.h"

    // Constructor
SortedLinkList::SortedLinkList ()   
{
 head = NULL;
}


bool SortedLinkList::IsEmpty () const
{
  return head == NULL;
} 

// case1: empty list
// case2.1: adding after tail node
// case2.2: adding in middle of two nodes
// case3: adding to head
void SortedLinkList::Insert(/* in */  ItemType  item)
{
 NodeType * ptr, * insertAfter; 
 NodeType * tmp = new NodeType;
 tmp->info = item; 

 ptr = head;
 insertAfter = NULL;
 while (ptr!=NULL && ptr->info < item)
 {
   insertAfter = ptr;
   ptr = ptr->link;
 }

 if (insertAfter!=NULL)
 {
  // tmp goes after insertAfter: case2.1 and case 2.2
  insertAfter->link = tmp;
  tmp->link = ptr;
 }
 else { // tmp becomes new head: case1 and case3
  tmp->link = head;
  head = tmp;
 }
}

void SortedLinkList::Delete (/* in */  ItemType  item)
{
  NodeType * prev = NULL;
  NodeType * ptr = head;
  while (ptr!=NULL && ptr->info < item)
  {
    prev = ptr;
    ptr = ptr->link;
  }
  if (ptr!=NULL && ptr->info == item)
  { 
   // item found at ptr; 
   // two cases: 
   // case1: prev exists; 
   // case2: head is equal to item, hence must be deleted
   if (prev!=NULL)
   {
    prev->link = ptr->link;
    ptr->link=NULL;
    delete ptr;
   }
   else // head item is deleted 
   {
     head = ptr->link;
     ptr->link=NULL;
     delete ptr;
   }
  }
}

void SortedLinkList::Print () const
{
 NodeType * tmp = head;
 while (tmp!=NULL)
 {
   cout<<tmp->info<<endl;
   tmp = tmp->link;
 }
}
	 
    // Destructor
SortedLinkList::~SortedLinkList ()  
{
  Free();
}

void SortedLinkList::Free()
{
 NodeType * current = head;
 while (current!=NULL)
 {
   NodeType * tmp;
   tmp = current->link;
   delete current;
   current = tmp;
 }
 head = NULL;
}

    // Copy-constructor
SortedLinkList::SortedLinkList (const SortedLinkList&  otherList) 
{
  cout<<"Copy constructor called"<<endl;

  NodeType* tmp, * prev, * current;
  prev = NULL;
  current = otherList.head;
  while (current!=NULL)
  {
    tmp = new NodeType;
    tmp->info = current->info;
    tmp->link = NULL;
    if (prev!=NULL)
    {
      prev->link = tmp;
      prev = tmp;
    }
    else prev = head = tmp;

    current = current->link;
  }

}

SortedLinkList & SortedLinkList::operator = (const SortedLinkList & otherList)
{
  cout<<"= called"<<endl;

  Free();

  NodeType* tmp, * prev, * current;
  prev = NULL;
  current = otherList.head;
  while (current!=NULL)
  {
    tmp = new NodeType;
    tmp->info = current->info;
    tmp->link = NULL;
    if (prev!=NULL)
    {
      prev->link = tmp;
      prev = tmp;
    }
    else prev = head = tmp;

    current = current->link;
  }
  
  return *this;
}

void SortedLinkList::ResetList()
{
	nodePtr = head;
}

ItemType* SortedLinkList::getNextItem()
{
	ItemType* item = & nodePtr->info;
	nodePtr = nodePtr->link;
	return item;
}

bool SortedLinkList::hasNext() const { return (nodePtr != NULL); }
