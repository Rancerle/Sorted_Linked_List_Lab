 // This program demonstrates deep copy via a copy constructor
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "sortedLinkList.h"

using namespace std;

int main()
{
 SortedLinkList myList;
 
 /* initialize random seed: */
 srand (time(NULL));
 
 int newNum;
 for (int i=0; i<5-1; ++i)
 {
   newNum = rand();
   cout<<newNum;
   cout<<",";
   myList.Insert(newNum);
 }
 newNum = rand();
 cout<<newNum;
 myList.Insert(newNum);

 cout<<endl;
  
 cout<<"myList:"<<endl;
 //myList.Print();
 myList.ResetList();
 while (myList.hasNext() == true)
 {
	 cout << *myList.getNextItem() << endl;
 }
 
 // Deep copy via the copy constructor
 SortedLinkList yourList(myList);
 //yourList = myList;
 cout<<endl;
 cout<<"yourList:"<<endl;
 //yourList.Print();
 yourList.ResetList();
 while (yourList.hasNext() == true)
 {
	 cout << *yourList.getNextItem() << endl;
 }


 yourList.ResetList();
*yourList.getNextItem() = 0;

yourList.ResetList();
while (yourList.hasNext() == true)
{
	cout << *yourList.getNextItem() << endl;
}


 cout<<"Enter a number to delete from myList:";
 int tmp;
 cin>> tmp;
 myList.Delete(tmp);
 cout<<"myList:"<<endl;
 //myList.Print();

 myList.ResetList();
 while (myList.hasNext() == true)
 {
	 cout << *myList.getNextItem() << endl;
 }

 cout<<"yourList:"<<endl;
 //yourList.Print();

 yourList.ResetList();
 while (yourList.hasNext() == true)
 {
	 cout << *yourList.getNextItem() << endl;
 }

 /*
 yourList = myList;
 cout<<"yourList:"<<endl;
 yourList.Print();
 */

 return 0;
}

