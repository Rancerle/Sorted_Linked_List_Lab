#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "sortedLinkList.h"

using namespace std;

int main()
{
 SortedLinkList myList;
 
 /* initialize random seed: */
 srand (time(NULL));
 
 int newNum;
 for (int i=0; i<5-1; ++i)
 {
   newNum = rand();
   cout<<newNum;
   cout<<",";
   myList.Insert(newNum);
 }
 newNum = rand();
 cout<<newNum;
 myList.Insert(newNum);

 cout<<endl;
  
 myList.Print();

/* test Delete()
 int tmp;
 cin>> tmp;
 myList.Delete(tmp);
 myList.Print();
 */

 return 0;
}

